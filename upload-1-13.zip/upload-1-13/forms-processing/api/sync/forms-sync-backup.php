<?php
// Include the helper file where forms_fetcher function is defined
include(__DIR__ . '/helper.php');


    // Call the forms_fetcher function to sync the forms
    forms_fetcher();
    
    

?>
