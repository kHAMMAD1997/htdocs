<?php
// Define email constants
define('PROGRAMS_EMAIL', 'programs@hammad-khan.org');
define('FINANCE_EMAIL', 'finance@hammad-khan.org');
?>
