<?php
// Define email constants
//======================IMPORTANT =============================================
//EMAIL_1 should always be the programs email
define('EMAIL_1', 'programs@mercywithoutlimits.org');
//======================IMPORTANT =============================================
define('EMAIL_2', 'finance@hammad-khan.org');
define('EMAIL_3', 'finance2@hammad-khan.org');
define('EMAIL_4', 'safwan@mercywithoutlimits.org');
define('EMAIL_5', 'hkhan@mercywithoutlimits.org');
?>
